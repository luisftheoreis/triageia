# TriageIA

Ferramenta web para equipes de TI e suporte técnico: você cola o texto de um chamado e recebe **categoria, prioridade, prazo (SLA), próximos passos de diagnóstico e uma resposta pronta** para enviar ao usuário.

Não precisa de servidor, build nem dependências. É um único `index.html`.

## Como usar

1. Abra o `index.html` no navegador (ou publique, veja abaixo).
2. Cole um chamado ou use um dos exemplos.
3. Escolha o modo de análise e clique em **Analisar chamado**.

### Dois modos

| Modo | Como funciona | Precisa de chave? |
|---|---|---|
| **Local (regras)** | Pontua palavras-chave por categoria e sinais de urgência. Funciona offline. | Não |
| **IA (Claude)** | Envia o chamado para a API da Anthropic e recebe a análise em JSON, com resposta sob medida. | Sim, a sua |

A chave é digitada na própria página, fica só no `sessionStorage` da aba e vai apenas para `api.anthropic.com`. **Nunca coloque a chave no código nem no repositório.**
Para uso real em equipe, o ideal é uma pequena API intermediária que guarde a chave no servidor.

## Publicar no GitHub Pages

1. Crie um repositório e envie `index.html` e `README.md`.
2. Em **Settings → Pages**, escolha a branch `main` e a pasta `/ (root)`.
3. Em alguns minutos o site fica em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.

## Recursos

- 7 categorias de TI (rede/VPN, acesso, e-mail, hardware, software, infraestrutura, segurança)
- 4 níveis de prioridade com SLA sugerido
- Histórico local (30 itens) e exportação em CSV
- Responsivo, com tema claro/escuro automático e navegação por teclado
- Saídas da IA exibidas com `textContent` (sem injeção de HTML)

## Limitações conhecidas

- O modo local é baseado em regras: não entende contexto como um modelo de linguagem.
- O histórico fica só no navegador de quem usou.

## Próximos passos

- API intermediária para esconder a chave
- Integração com Jira, GLPI ou Zendesk
- Base de conhecimento (RAG) com soluções de chamados anteriores
- Avaliação da qualidade da triagem contra chamados reais já classificados
